setwd("C:\\Users\\it24103288\\Desktop")

Delivery_Times <- read.table("Exercise - Lab 05", header = TRUE)
str(Delivery_Times)


breaks <- seq(20, 70, by = (70 - 20) / 9)


hist(Delivery_Times$Delivery_Time, 
     breaks = breaks, 
     main = "Histogram of Delivery Times", 
     xlab = "Delivery Time", 
     col = "skyblue", 
     border = "black", 
     right = TRUE)

# Calculate cumulative frequencies
Delivery_Times$Delivery_Time_Freq <- hist(Delivery_Times$Delivery_Time, 
                                          breaks = breaks, 
                                          plot = FALSE)$counts


Delivery_Times$Cumulative_Frequency <- cumsum(Delivery_Times$Delivery_Time_Freq)


plot(breaks[-length(breaks)], 
     Delivery_Times$Cumulative_Frequency, 
     type = "o", 
     col = "blue", 
     xlab = "Delivery Time", 
     ylab = "Cumulative Frequency", 
     main = "Cumulative Frequency Polygon (Ogive)", 
     pch = 16, 
     lwd = 2)
