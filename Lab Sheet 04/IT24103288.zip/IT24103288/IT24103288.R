setwd("C:\Users\it24103288\Desktop")
data<=read.table("DATA 4.txt",header=TRUE,sep - "")
# Import dataset
branch_data <- read.table("C:\Users\it24103288\Desktop", header = TRUE)
# View the first few rows of the dataset
head(branch_data)
# View structure of the dataset
str(branch_data)
# Create boxplot for sales
boxplot(branch_data$sales, main = "Boxplot for Sales", ylab = "Sales", col = "lightblue")
# Five number summary for advertising variable
fivenum(branch_data$advertising)

# Calculate IQR for advertising
IQR_advertising <- IQR(branch_data$advertising)
print(IQR_advertising)
# Function to find outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in the 'years' variable
outliers_years <- find_outliers(branch_data$years)
print(outliers_years)


